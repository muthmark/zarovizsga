module.exports = {
    semi: true,
    trailingComma: "all",
    printWidth: 999,
    tabWidth: 4,
    endOfLine: "auto",
    arrowParens: "avoid"
  };